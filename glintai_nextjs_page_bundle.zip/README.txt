# Glint AI Landing Page (Next.js App Router)

This bundle includes a ready-to-drop **Next.js page** plus minimal UI components.

## Files
- `app/page.tsx` — the full landing page (client component)
- `components/ui/button.tsx` — minimal Button used by the page
- `components/ui/card.tsx` — minimal Card primitives used by the page

## Requirements
- Next.js 13+ (App Router)
- Tailwind CSS
- Dependencies: `framer-motion`, `lucide-react`

Install:
```bash
npm i framer-motion lucide-react
```

## EmailJS
The page can send emails out-of-the-box in Preview using fallback keys. For Production, add env vars in Vercel (Project → Settings → Environment Variables):

- `NEXT_PUBLIC_EMAILJS_SERVICE_ID`
- `NEXT_PUBLIC_EMAILJS_TEMPLATE_ID`
- `NEXT_PUBLIC_EMAILJS_PUBLIC_KEY`

Optionally, you can also expose a `window.__env = { ... }` object for runtime injection if you don't want to rebuild.

## Usage
Copy the `app/` and `components/` folders into your Next.js project root (merge if they exist). Visit `http://localhost:3000/`.

## Notes
- Scroll spy uses **center-of-viewport** logic to keep the blue underline perfectly synced.
- The sticky header offset is accounted for in smooth scrolling.
- Animations are powered by Framer Motion.
